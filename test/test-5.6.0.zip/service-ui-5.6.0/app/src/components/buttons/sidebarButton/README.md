## **Admin sidebar button**

Has width of it's parent and height adjusted by content.

### Props:

- **icon**: _string(imported inline svg icon)_, optional, default = ""
- **link**: _string_, optional, default = "/"
- **bottom**: _bool_, optional, default = false
- **children**: _node_, optional, default = null

### Events:

- **onClick**
