## **Big colored button**

Has no own size. Width and Height = 100% of it's parent.

### Props:

- **type**: _string_, optional, default = "button"
- **disabled**: _bool_, optional, default = false
- **color**: _string_, optional, default = "booger"
- **roundedCorners**: _bool_, optional, default = false
- **children**: _node_, optional, default= ""

### Events:

- **onClick**

To define a new color your should describe it in bigButton.scss file.
