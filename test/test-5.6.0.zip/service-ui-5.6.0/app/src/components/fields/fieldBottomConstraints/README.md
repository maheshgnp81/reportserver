## **Field wrapper with constraints text at the bottom**

Has no own size. Width and Height = 100% of it's parent.

> Should wrap all others field wrapping components

### Props:

- **formPath**: _string_, optional, default = "", passes into nested components (children)
- **fieldName**: _string_, optional, default = "", passes into nested components (children)
- **text**: _node_, optional, default = ""
- **children**: _node_, optional, default = null
