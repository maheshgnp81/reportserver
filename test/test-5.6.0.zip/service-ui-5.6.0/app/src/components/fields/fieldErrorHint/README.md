## **Field wrapper with hint for errors**

Has no own size. Width and Height = 100% of it's parent.

> Should wrap all others field wrapping components

### Props:

- **formPath**: _string_, optional, default = "", passes into nested components (children)
- **fieldName**: _string_, optional, default = "", passes into nested components (children)
- **children**: _node_, optional, default = null
- **error**: _string_, optional, default = ""
- **hintType**: _string_, optional, default = ""
- **active**: _bool_, optional, default = false
