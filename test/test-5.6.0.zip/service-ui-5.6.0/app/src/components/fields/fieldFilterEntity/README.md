## **Field wrapper with hint for errors**

Has 55px height & 235px width.
With stretchable has min-height 55px & min-width 235px.

> Should wrap all others field wrapping components

### Props:

- **children**: _node_, optional, default = null
- **title**: _string_, optional, default = ""
- **removable**: _bool_, optional, default = true
- **stretchable**: _bool_, optional, default = false

### Events

- **onRemove**
