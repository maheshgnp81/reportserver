## **Component for show time in absolute or relative format**

Height & width grows with it's content.

### Props :

- **startTime**: _number_, optional, default = 0
- **startTimeFormat**: one of [START_TIME_FORMAT_RELATIVE, START_TIME_FORMAT_ABSOLUTE], optional, default = START_TIME_FORMAT_RELATIVE
- **setStartTimeFormatAction**: _func_, required
