## **Typical radio field with optional text\***

Has no own size. Width and Height = 100% of it's parent.

### Props:

- **children**: _node_, optional, default = null
- **value**: _string_, optional, default = ""
- **ownValue**: _string_, optional, default = ""
- **name**: _string_, optional, default = ""
- **disabled**: _bool_, optional, default = false
- **mobileDisabled**: _bool_, optional, default = false
- **circleAtTop**: _bool_, optional, default = false
- **title**: _string_, optional, default = children
- **mode**: _string_, optional("default" || "dark"), default = "default"

### Events:

- **onFocus**
- **onBlur**
- **onChange**
