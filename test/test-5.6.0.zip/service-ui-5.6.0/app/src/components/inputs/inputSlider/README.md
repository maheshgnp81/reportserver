## **InputSlider component**

Component uses rc-slider library. https://github.com/react-component/slider

### Props:

- **options**: _array_, optional, default = []
- **value**: _string_, optional, default = ""

### Events:

- **onChange**
