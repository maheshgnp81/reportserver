## **Conditional input with tags**

Has 30px min-height & width adjusted by content.

### Props:

- **value**: _object_, optional, default = {}
- **getURI**: _function_, \_required. Function which get input value and should return search uri.
- **conditions**: _array of strings_, optional, default = []
- **placeholder**: _string_, optional, default = ""

### Events:

- **onFocus**
- **onBlur**
- **onChange**
