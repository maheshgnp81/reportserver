## **Field for set time and date range**

Has 30px height & width adjusted by content.

### Props:

- **value**: _object_, optional, default = {}
- **presets**: _array_, optional, default = []

### Events:

- **onFocus**
- **onBlur**
- **onChange**
