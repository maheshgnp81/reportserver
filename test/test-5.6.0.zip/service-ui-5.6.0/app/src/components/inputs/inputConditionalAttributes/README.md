## **Input Conditional Attributes**

Has 30px min-height & width adjusted by content.

### Props:

- **value**: _object_, optional, default = {}
- **conditions**: _array of strings_, optional, default = []
- **projectId**: _string_, optional, default = ''
- **valueURLCreator**:_function_, optional, default =() => {}
- **keyURLCreator**:_function_, optional, default =() => {}

### Events:

- **onFocus**
- **onBlur**
- **onChange**
