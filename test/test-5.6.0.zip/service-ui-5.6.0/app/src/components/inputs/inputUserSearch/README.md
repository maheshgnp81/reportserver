## **InputUserSearch component**

Has no own size. Width = 100% of it's parent. Allows user searching.

### Props:

- **isAdmin**: _bool_, optional, default = false
- **projectId**: _string_, optional, default = ""
- **placeholder**: _string_, optional, default = ""
- **value**: _string_, optional, default = {}
- **error**: _bool_, optional, default = false
- **touched**: _bool_, optional, default = false

### Events:

- **onChange**
