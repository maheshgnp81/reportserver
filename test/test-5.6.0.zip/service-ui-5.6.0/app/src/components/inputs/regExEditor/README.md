## **Code editor **

Typically used as RegExp editor.

### Props:

- **value**: _string_, optional, default = ""
- **options**: _object_, optional, default = {}
- **error**: _string_, optional, default = ""
- **readonly**: _bool_, optional, default = false
- **touched**: _bool_, optional, default = false

### Events:

- **onFocus**
- **onBlur**
- **onChange**
