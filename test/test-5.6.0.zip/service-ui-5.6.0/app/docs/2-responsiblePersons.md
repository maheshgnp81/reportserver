# Responsible Persons

**Product Owner** - [Dmitriy Gumeniuk](https://telescope.epam.com/who/Dmitriy_Gumeniuk)<br/>
Product related questions. Promotion.

**Project Manager & Delivery Manager** - [Ilya Nazarov](https://telescope.epam.com/who/Ilya_Nazarov)<br/>
Organization & delivery questions.

**Business Analyst** - [Yauheniya Labanava](https://telescope.epam.com/who/Yauheniya_Labanava)<br/>
Requirements related questions. Responsible for task descriptions.

**Solution Architect** - [Andrei Varabyeu](https://telescope.epam.com/who/Andrei_Varabyeu)<br/>
WS architecture related questions. Github account - [avarabyeu](https://github.com/avarabyeu)

**WS Team Leader** - [Maksim Antonov](https://telescope.epam.com/who/Maksim_Antonov)<br/>
WS related questions. Github account - [miracle8484](https://github.com/miracle8484)

**WS Key Developer** - [Pavel Bortnik](https://telescope.epam.com/who/Pavel_Bortnik)<br/>
WS development related questions. Github account - [pbortnik](https://github.com/pbortnik)

**UI Team Leader** - [Ilya Hancharyk](https://telescope.epam.com/who/Ilya_Hancharyk)<br/>
UI related questions. Github account - [AmsterGet](https://github.com/AmsterGet)

**UX Design Team Leader** - [Vitalii Oleksiuk](https://telescope.epam.com/who/Vitalii_Oleksiuk)<br/>
UX & Design related questions.

**QA Team Leader** - [Valentina Svettsova](https://telescope.epam.com/who/Valentina_Svettsova)<br/>
Testing & Project functionality related questions.
