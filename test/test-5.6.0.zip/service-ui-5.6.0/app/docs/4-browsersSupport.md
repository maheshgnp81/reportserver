# Browsers Support

- Google Chrome - 62 and higher.
- Mozila Firefox - 61 and higher.
- Safari - 11 and higher.
- Edge - 16 and higher.
- Internet Explorer - 11 and higher.
- Opera - 54 and higher.

> We are strongly recommend to use latest versions of browsers.<br> > [Get latest](http://outdatedbrowser.com/en)
